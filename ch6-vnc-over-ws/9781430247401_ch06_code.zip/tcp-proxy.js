//
// Definitive Guide to HTML5 WebSocket
//

var websocket = require("./websocket-example");
var net = require("net");

var remotePort = 5900;
var remoteHost = "192.168.56.101";

websocket.listen(8080, "localhost", function(websocket) {
    // set up backend TCP connection
    var tcpsocket = new net.Socket({type:"tcp4"});
    tcpsocket.connect(remotePort, remoteHost);

    // TCP handler functions
    tcpsocket.on("connect", function() {
      console.log("TCP connection open");
    });
    tcpsocket.on("data", function(data) {
      websocket.send(data);
    });
    tcpsocket.on("error", function() {
      console.log("TCP connection error", arguments);
    });

    // WebSocket handler functions
    websocket.on("data", function(opcode, data) {
        tcpsocket.write(data);
    });
    websocket.on("close", function(code, reason) {
        console.log("WebSocket closed")
        // close backend connection
        tcpsocket.end();
    });

    console.log("WebSocket connection open");
});

